package com.example.entity;

import lombok.Data;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("t_purchase")
public class TPurchase extends Model<TPurchase> {
    /**
      * 主键
      */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private String productNameRel;

    private Integer productId;

    private Integer quantity;

    private BigDecimal price;

    private String purchaseDate;

    /**
      * 剩余数量 
      */
    private Integer residueQuantity;

}