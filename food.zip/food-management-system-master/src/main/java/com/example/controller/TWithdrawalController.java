package com.example.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.example.common.Result;
import com.example.entity.TPurchase;
import com.example.entity.TWithdrawal;
import com.example.service.TPurchaseService;
import com.example.service.TWithdrawalService;
import com.example.entity.User;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.web.bind.annotation.*;
import com.example.exception.CustomException;
import cn.hutool.core.util.StrUtil;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/tWithdrawal")
public class TWithdrawalController {
    @Resource
    private TWithdrawalService tWithdrawalService;
    @Resource
    private TPurchaseService tPurchaseService;
    @Resource
    private HttpServletRequest request;

    public User getUser() {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            throw new CustomException("-1", "请登录");
        }
        return user;
    }

    @PostMapping
    public Result<?> save(@RequestBody TWithdrawal tWithdrawal) {
        //1. 查询进货表
        List<TPurchase> tPurchaseList = tPurchaseService.getTPurchaseList(tWithdrawal.getProductNameRel());
        if (CollectionUtils.isEmpty(tPurchaseList)) {
            String message = String.format("%s无库存,请先进货,再领用", tWithdrawal.getProductNameRel());
            return Result.error("201",message);
        }
        TPurchase tPurchase = tPurchaseList.get(0);
        //2. 领用数量不能大于进货剩余数量
        if (tWithdrawal.getQuantity() > tPurchase.getResidueQuantity()) {
            String message = String.format("%s领用数量%s大于了剩余数量%s,领用失败", tWithdrawal.getProductNameRel(),tWithdrawal.getQuantity(),tPurchase.getResidueQuantity());
            return Result.error("201",message);
        }
        //3. 如果正常领用,剩余数量 = 剩余数量-领用数量
        tPurchase.setResidueQuantity(tPurchase.getResidueQuantity() - tWithdrawal.getQuantity());
        //4. 更新进货表
        tPurchaseService.updateById(tPurchase);
        //5. 保存领用信息表
        return Result.success(tWithdrawalService.save(tWithdrawal));
    }

    @PutMapping
    public Result<?> update(@RequestBody TWithdrawal tWithdrawal) {
        return Result.success(tWithdrawalService.updateById(tWithdrawal));
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        tWithdrawalService.removeById(id);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result<?> findById(@PathVariable Long id) {
        return Result.success(tWithdrawalService.getById(id));
    }

    @GetMapping
    public Result<?> findAll() {
        return Result.success(tWithdrawalService.list());
    }

    @GetMapping("/page")
    public Result<?> findPage(@RequestParam(required = false, defaultValue = "") String name,
                                                @RequestParam(required = false, defaultValue = "1") Integer pageNum,
                                                @RequestParam(required = false, defaultValue = "10") Integer pageSize) {
        LambdaQueryWrapper<TWithdrawal> query = Wrappers.<TWithdrawal>lambdaQuery().orderByDesc(TWithdrawal::getId);
        if (StrUtil.isNotBlank(name)) {
            query.like(TWithdrawal::getProductNameRel, name);
        }
        return Result.success(tWithdrawalService.page(new Page<>(pageNum, pageSize), query));
    }

    @GetMapping("/export")
    public void export(HttpServletResponse response) throws IOException {

        List<Map<String, Object>> list = CollUtil.newArrayList();

        List<TWithdrawal> all = tWithdrawalService.list();
        for (TWithdrawal obj : all) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("", obj.getId());
            row.put("", obj.getProductNameRel());
            row.put("", obj.getProductId());
            row.put("", obj.getQuantity());
            row.put("", obj.getWithdrawalDate());
            row.put("", obj.getPersonnel());

            list.add(row);
        }

        // 2. 写excel
        ExcelWriter writer = ExcelUtil.getWriter(true);
        writer.write(list, true);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        String fileName = URLEncoder.encode("领料信息", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

        ServletOutputStream out = response.getOutputStream();
        writer.flush(out, true);
        writer.close();
        IoUtil.close(System.out);
    }

    @GetMapping("/upload/{fileId}")
    public Result<?> upload(@PathVariable String fileId) {
        String basePath = System.getProperty("user.dir") + "/src/main/resources/static/file/";
        List<String> fileNames = FileUtil.listFileNames(basePath);
        String file = fileNames.stream().filter(name -> name.contains(fileId)).findAny().orElse("");
        List<List<Object>> lists = ExcelUtil.getReader(basePath + file).read(1);
        List<TWithdrawal> saveList = new ArrayList<>();
        for (List<Object> row : lists) {
            TWithdrawal obj = new TWithdrawal();
            obj.setProductNameRel((String) row.get(1));
            obj.setProductId(Integer.valueOf((String) row.get(2)));
            obj.setQuantity(Integer.valueOf((String) row.get(3)));
            obj.setWithdrawalDate((String) row.get(4));
            obj.setPersonnel((String) row.get(5));

            saveList.add(obj);
        }
        tWithdrawalService.saveBatch(saveList);
        return Result.success();
    }

}
