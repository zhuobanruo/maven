package com.example.service;

import com.example.entity.TWithdrawal;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.mapper.TWithdrawalMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class TWithdrawalService extends ServiceImpl<TWithdrawalMapper, TWithdrawal> {

    @Resource
    private TWithdrawalMapper tWithdrawalMapper;

}
