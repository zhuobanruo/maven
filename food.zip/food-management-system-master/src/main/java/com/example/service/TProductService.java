package com.example.service;

import com.example.entity.TProduct;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.mapper.TProductMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class TProductService extends ServiceImpl<TProductMapper, TProduct> {

    @Resource
    private TProductMapper tProductMapper;

}
