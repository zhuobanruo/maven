package com.example.service;

import com.example.entity.Provider;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.mapper.ProviderMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
//供应商
@Service
public class ProviderService extends ServiceImpl<ProviderMapper, Provider> {

    @Resource
    private ProviderMapper providerMapper;

}
