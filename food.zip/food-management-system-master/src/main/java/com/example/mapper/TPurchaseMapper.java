package com.example.mapper;

import com.example.entity.TPurchase;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface TPurchaseMapper extends BaseMapper<TPurchase> {

}
