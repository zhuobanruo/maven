package com.example.mapper;

import com.example.entity.Log;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface LogMapper extends BaseMapper<Log> {

}
