package com.example.mapper;

import com.example.entity.TWithdrawal;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface TWithdrawalMapper extends BaseMapper<TWithdrawal> {

}
