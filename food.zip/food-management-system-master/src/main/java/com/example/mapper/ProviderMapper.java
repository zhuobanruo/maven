package com.example.mapper;

import com.example.entity.Provider;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ProviderMapper extends BaseMapper<Provider> {

}
