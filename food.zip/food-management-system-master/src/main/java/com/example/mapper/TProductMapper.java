package com.example.mapper;

import com.example.entity.TProduct;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface TProductMapper extends BaseMapper<TProduct> {

}
