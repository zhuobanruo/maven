package com.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.entity.Role;

public interface RoleMapper extends BaseMapper<Role> {

}
