/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 50559
 Source Host           : 127.0.0.1:3306
 Source Schema         : x-admin

 Target Server Type    : MySQL
 Target Server Version : 50559
 File Encoding         : 65001

 Date: 01/07/2023 17:21:33
*/
create database `food-management-system`;
use `food-management-system`;


SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES (2, '1', 11.11);

-- ----------------------------
-- Table structure for t_log
-- ----------------------------
DROP TABLE IF EXISTS `t_log`;
CREATE TABLE `t_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `content` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作时间',
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'ip',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 189 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_log
-- ----------------------------
INSERT INTO `t_log` VALUES (80, '用户 admin 登录系统', '2021-05-25 16:42:07', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (81, '更新用户：admin ', '2021-05-25 16:42:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (82, '用户 admin 退出系统', '2021-05-25 16:42:29', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (83, '用户 admin 登录系统', '2021-05-25 16:42:31', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (84, '更新用户：jerry ', '2021-05-25 16:49:14', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (85, '用户 admin 登录系统', '2021-05-25 16:49:30', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (86, '用户 admin 登录系统', '2021-05-25 16:50:07', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (87, '更新用户：jerry ', '2021-05-25 16:50:21', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (88, '用户 admin 登录系统', '2021-05-26 16:35:40', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (89, '更新用户：jerry ', '2021-05-26 16:36:16', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (90, '更新用户：jack ', '2021-05-26 16:36:18', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (91, '删除用户 tom ', '2021-05-26 16:36:29', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (92, '删除用户 hello ', '2021-05-26 16:36:30', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (93, '删除用户 jack ', '2021-05-26 16:36:31', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (94, '删除用户 jerry ', '2021-05-26 16:36:32', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (95, '用户 admin 登录系统', '2021-05-31 12:18:16', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (96, '更新用户：admin ', '2021-05-31 12:19:48', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (97, '更新用户：admin ', '2021-05-31 12:19:57', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (98, '用户 admin 登录系统', '2021-06-01 16:46:09', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (99, '新增用户：zhang ', '2021-06-01 16:46:46', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (100, '新增用户：li ', '2021-06-01 16:47:12', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (101, '更新用户：admin ', '2021-06-01 16:47:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (102, '用户 admin 退出系统', '2021-06-01 16:47:22', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (103, '用户 admin 登录系统', '2021-06-01 16:47:24', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (104, '更新用户：li ', '2021-06-01 16:47:34', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (105, '更新用户：zhang ', '2021-06-01 16:47:35', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (106, '用户 admin 登录系统', '2021-06-07 12:32:17', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (107, '用户 admin 登录系统', '2021-06-07 14:16:00', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (108, '用户 admin 登录系统', '2021-06-07 14:34:26', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (109, '更新用户：li ', '2021-06-07 14:35:21', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (110, '更新用户：li ', '2021-06-07 14:35:23', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (111, '更新角色：超级管理员', '2021-06-07 14:35:41', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (112, '更新角色：超级管理员', '2021-06-07 14:35:45', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (113, '更新权限菜单：用户管理', '2021-06-07 14:37:58', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (114, '更新权限菜单：用户管理', '2021-06-07 14:38:08', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (115, '更新权限菜单：用户管理', '2021-06-07 14:38:13', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (116, '更新权限菜单：用户管理', '2021-06-07 14:38:21', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (117, '用户 admin 登录系统', '2021-06-07 14:57:29', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (118, '更新角色：超级管理员', '2021-06-07 14:57:43', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (119, '用户 admin 登录系统', '2021-06-09 23:19:38', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (120, '删除权限菜单：学生管理', '2021-06-09 23:19:50', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (121, '用户 admin 登录系统', '2021-06-12 10:18:54', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (122, '更新角色：超级管理员', '2021-06-12 10:30:15', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (123, '用户 admin 登录系统', '2021-06-12 13:55:01', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (124, '用户 admin 登录系统', '2021-06-27 10:44:12', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (125, '更新角色：超级管理员', '2021-06-27 10:44:26', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (126, '用户 admin 登录系统', '2021-06-27 11:15:11', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (127, '更新角色：超级管理员', '2021-06-27 11:15:17', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (128, '用户 admin 登录系统', '2021-06-27 11:18:36', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (129, '用户 admin 登录系统', '2021-06-27 11:41:59', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (130, '更新角色：超级管理员', '2021-06-27 11:42:04', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (131, '用户 admin 登录系统', '2021-06-27 11:49:27', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (132, '用户 admin 登录系统', '2023-05-15 21:12:55', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (133, '用户 admin 退出系统', '2023-05-15 21:15:31', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (134, '用户 admin 登录系统', '2023-05-15 21:15:55', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (135, '用户 admin 退出系统', '2023-05-15 21:17:35', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (136, '用户 zhang 登录系统', '2023-05-15 21:17:40', 'zhang', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (137, '用户 zhang 退出系统', '2023-05-15 21:17:55', 'zhang', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (138, '用户 admin 登录系统', '2023-07-01 09:55:41', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (139, '用户 admin 登录系统', '2023-07-01 10:06:28', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (140, '用户 admin 退出系统', '2023-07-01 10:08:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (141, '用户 admin 登录系统', '2023-07-01 10:08:20', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (142, '用户 admin 退出系统', '2023-07-01 10:16:22', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (143, '用户 admin 登录系统', '2023-07-01 10:16:23', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (144, '用户 admin 登录系统', '2023-07-01 11:20:18', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (145, '用户 admin 登录系统', '2023-07-01 14:18:09', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (146, '用户 admin 登录系统', '2023-07-01 14:20:43', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (147, '用户 admin 登录系统', '2023-07-01 14:45:35', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (148, '用户 admin 登录系统', '2023-07-01 14:55:54', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (149, '用户 admin 登录系统', '2023-07-01 15:30:32', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (150, '用户 admin 退出系统', '2023-07-01 15:30:53', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (151, '用户 admin 登录系统', '2023-07-01 15:30:54', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (152, '用户 admin 登录系统', '2023-07-01 15:45:15', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (153, '用户 admin 登录系统', '2023-07-01 16:40:30', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (154, '用户 admin 登录系统', '2023-07-01 16:42:35', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (155, '用户 admin 登录系统', '2023-07-01 16:48:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (156, '用户 admin 登录系统', '2023-07-01 16:49:41', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (157, '用户 admin 退出系统', '2023-07-01 16:52:09', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (158, '用户 admin 登录系统', '2023-07-01 16:52:10', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (159, '更新用户：lisi ', '2023-07-01 16:52:25', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (160, '更新用户：zhangsan ', '2023-07-01 16:52:32', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (161, '新增用户：wangwu ', '2023-07-01 16:53:09', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (162, '新增角色：领料员', '2023-07-01 16:53:58', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (163, '更新角色：领料员', '2023-07-01 16:54:02', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (164, '新增角色：进货员', '2023-07-01 16:54:22', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (165, '更新角色：进货员', '2023-07-01 16:54:34', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (166, '更新角色：领料员', '2023-07-01 16:55:00', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (167, '更新用户：wangwu ', '2023-07-01 16:55:19', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (168, '新增用户：xiaoming ', '2023-07-01 16:55:47', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (169, '更新用户：xiaoming ', '2023-07-01 16:55:52', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (170, '用户 admin 退出系统', '2023-07-01 16:56:00', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (171, '用户 xiaoming 登录系统', '2023-07-01 16:56:08', 'xiaoming', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (172, '用户 xiaoming 退出系统', '2023-07-01 16:56:54', 'xiaoming', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (173, '用户 admin 登录系统', '2023-07-01 16:56:57', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (174, '更新角色：进货员', '2023-07-01 16:57:14', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (175, '用户 admin 退出系统', '2023-07-01 16:57:21', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (176, '用户 xiaoming 登录系统', '2023-07-01 16:57:25', 'xiaoming', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (177, '用户 xiaoming 退出系统', '2023-07-01 17:07:56', 'xiaoming', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (178, '用户 xiaoming 登录系统', '2023-07-01 17:08:04', 'xiaoming', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (179, '用户 xiaoming 退出系统', '2023-07-01 17:08:09', 'xiaoming', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (180, '用户 admin 登录系统', '2023-07-01 17:08:16', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (181, '用户 admin 退出系统', '2023-07-01 17:10:30', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (182, '用户 admin 登录系统', '2023-07-01 17:10:31', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (183, '用户 admin 退出系统', '2023-07-01 17:10:58', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (184, '用户 admin 登录系统', '2023-07-01 17:10:59', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (185, '用户 admin 退出系统', '2023-07-01 17:11:51', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (186, '用户 admin 登录系统', '2023-07-01 17:11:52', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (187, '用户 admin 退出系统', '2023-07-01 17:11:57', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `t_log` VALUES (188, '用户 admin 登录系统', '2023-07-01 17:20:09', 'admin', '0:0:0:0:0:0:0:1');

-- ----------------------------
-- Table structure for t_message
-- ----------------------------
DROP TABLE IF EXISTS `t_message`;
CREATE TABLE `t_message`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '内容',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论人',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '评论时间',
  `parent_id` bigint(20) NULL DEFAULT NULL COMMENT '父ID',
  `foreign_id` bigint(20) NULL DEFAULT 0 COMMENT '关联id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '留言表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_message
-- ----------------------------
INSERT INTO `t_message` VALUES (16, '我来了', 'admin', '2021-04-23 23:15:57', NULL, 0);
INSERT INTO `t_message` VALUES (17, '来了老弟', 'admin', '2021-04-23 23:17:46', 16, 0);
INSERT INTO `t_message` VALUES (19, '今天直播', 'admin', '2021-04-24 11:08:41', 17, 0);

-- ----------------------------
-- Table structure for t_notice
-- ----------------------------
DROP TABLE IF EXISTS `t_notice`;
CREATE TABLE `t_notice`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_notice
-- ----------------------------
INSERT INTO `t_notice` VALUES (4, '学习', '别问！问就是3连！', '2021-05-17 15:29:29');
INSERT INTO `t_notice` VALUES (5, '快乐是什么？', '快乐就是一杯咖啡，一个键盘，从早到晚', '2021-05-17 15:30:08');
INSERT INTO `t_notice` VALUES (6, 'Java是什么', 'Java是世界上最好的语言', '2021-05-17 15:30:42');

-- ----------------------------
-- Table structure for t_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '菜单路径',
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 's-data' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限菜单表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES (1, '用户管理', '用户管理', 'user', 'user-solid');
INSERT INTO `t_permission` VALUES (2, '角色管理', '角色管理', 'role', 's-cooperation');
INSERT INTO `t_permission` VALUES (3, '权限管理', '权限管理', 'permission', 'menu');
INSERT INTO `t_permission` VALUES (34, '商品管理', '商品管理', 'tProduct', 'menu');
INSERT INTO `t_permission` VALUES (35, '领料管理', '领料管理', 'tWithdrawal', 'menu');
INSERT INTO `t_permission` VALUES (36, '进货管理', '进货管理', 'tPurchase', 'menu');

-- ----------------------------
-- Table structure for t_product
-- ----------------------------
DROP TABLE IF EXISTS `t_product`;
CREATE TABLE `t_product`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `purchase_price` decimal(10, 2) NOT NULL,
  `selling_price` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_product
-- ----------------------------
INSERT INTO `t_product` VALUES (1, '可乐', '瓶', 2.40, 3.50);
INSERT INTO `t_product` VALUES (2, '鸡翅', '支', 5.50, 10.00);
INSERT INTO `t_product` VALUES (3, '果冻', '盒', 10.00, 20.00);
INSERT INTO `t_product` VALUES (4, '猪肉', '斤', 20.00, 30.00);
INSERT INTO `t_product` VALUES (5, '大白菜', '棵', 20.00, 25.00);

-- ----------------------------
-- Table structure for t_purchase
-- ----------------------------
DROP TABLE IF EXISTS `t_purchase`;
CREATE TABLE `t_purchase`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `purchase_date` date NOT NULL,
  `residue_quantity` int(11) NULL DEFAULT NULL COMMENT '剩余数量',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `product_id`(`product_id`) USING BTREE,
  CONSTRAINT `t_purchase_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `t_product` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_purchase
-- ----------------------------
INSERT INTO `t_purchase` VALUES (1, '可乐', 1, 200, 5.00, '2023-07-01', 180);
INSERT INTO `t_purchase` VALUES (6, '大白菜', 5, 50, 50.00, '2023-07-29', 15);

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `permission` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限列表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES (1, '超级管理员', '所有权限', '[1,2,3,19,27,30,31,34,35,36]');
INSERT INTO `t_role` VALUES (2, '普通用户', '部分权限', '[]');
INSERT INTO `t_role` VALUES (3, '领料员', '领取食品商品货料', '[35]');
INSERT INTO `t_role` VALUES (4, '进货员', '用来进行商品进货记录', '[34,36]');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `nick_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '昵称',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '地址',
  `age` int(11) NULL DEFAULT NULL COMMENT '年龄',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES (1, 'admin', 'admin', '管理员', '111124444', '13978786565', '1622537239707', '[1]', '北京', NULL);
INSERT INTO `t_user` VALUES (2, 'zhangsan', '123456', '张三', 'zhang@qq.com', '13089897878', NULL, '[2]', '北京', 24);
INSERT INTO `t_user` VALUES (3, 'lisi', '123456', '李四', 'li@qq.com', '13989897898', NULL, '[2]', '南京', 22);
INSERT INTO `t_user` VALUES (4, 'wangwu', '123456', '王五', '163@qq.com', '15525536522', NULL, '[3]', '杭州', 22);
INSERT INTO `t_user` VALUES (5, 'xiaoming', '123456', 'xiaoming', 'xiaoming@163.com', '16599952365', NULL, '[4]', '南京', 23);

-- ----------------------------
-- Table structure for t_withdrawal
-- ----------------------------
DROP TABLE IF EXISTS `t_withdrawal`;
CREATE TABLE `t_withdrawal`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `withdrawal_date` date NOT NULL,
  `personnel` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `product_id`(`product_id`) USING BTREE,
  CONSTRAINT `t_withdrawal_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `t_product` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of t_withdrawal
-- ----------------------------
INSERT INTO `t_withdrawal` VALUES (2, '可乐', 1, 20, '2023-07-01', '李四');

SET FOREIGN_KEY_CHECKS = 1;
